package brewDay;

public class Recipe {
	
}
